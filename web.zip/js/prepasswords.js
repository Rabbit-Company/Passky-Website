if(localStorage.url == null || typeof(localStorage.url) == 'undefined') window.location.href = 'index.html';
if(localStorage.username == null || typeof(localStorage.username) == 'undefined') window.location.href = 'index.html';
if(localStorage.password == null || typeof(localStorage.password) == 'undefined') window.location.href = 'index.html';
if(localStorage.passwords == null || typeof(localStorage.passwords) == 'undefined') window.location.href = 'index.html';
